
// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Alert for "Buy KAWA"
document.getElementById('buy-btn').addEventListener('click', function () {
    alert('Thank you for your interest! CherryKawaii (KAWA) will be available soon.');
});

// Tokenomics section animation
const tokenomics = document.getElementById('tokenomics');
window.addEventListener('scroll', () => {
    const rect = tokenomics.getBoundingClientRect();
    if (rect.top < window.innerHeight && rect.bottom >= 0) {
        tokenomics.style.opacity = 1;
        tokenomics.style.transform = 'translateY(0)';
    }
});

// Load animation
window.addEventListener('load', () => {
    document.body.style.opacity = 1;
    document.body.style.transition = 'opacity 1s';
});
